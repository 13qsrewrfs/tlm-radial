# 车万女仆：圆环菜单 (TLM Radial)

车万女仆（Touhou Little Maid）的圆环互动菜单。长按 CapsLock（可改键）打开，鼠标选方向，松手执行。

当前版本：**0.2.0**（发布候选）

## 功能

- 两页圆环，滚轮 / Q / E 翻页
- 第一页按已安装的可选模组动态生成：
  - **动作拓展**：摸头 / 拥抱 / 膝枕
  - **爱恋**：亲亲 / 抱吻
  - **内置**：握手
- 第二页（动作拓展存在时）：牵手 / 侧靠 / 举高 / 背着 / 梳尾 / 埋脸 / 背抱 / 同坐
- 多只女仆时必须用准心对准；只有一只时自动锁定
- 好感走 TLM `FavorabilityManager`，爱恋羁绊同步
- 公开 Java API + JSON 命令条目，可自行加页/加项

## 依赖

| 类型 | 模组 | 版本 |
|---|---|---|
| 必需 | Minecraft | 1.21.1 |
| 必需 | NeoForge | 21.1.250+ |
| 必需 | 车万女仆 | 1.5.3 |
| 可选 | 动作拓展（winefox_companion） | 0.3.0+ |
| 可选 | 爱恋（touhou_maid_affection） | 1.7.5.2+ |

可选模组缺失时，对应项不会注册，不会出现死按钮。

## 安装

把 jar 放进：

```
.minecraft/versions/<版本>/mods/
```

## 使用

- 默认键 `CapsLock`；**选项 → 控制 → 按键绑定 → GLT 圆环菜单** 可改
- 16 格内只有一只女仆：自动锁定
- 有多只：准心对准其中一只，否则全部 `[无]`
- 拥抱要求距离 ≤1 格
- 松手执行；Esc 取消

## 自己加条目

### JSON

`config/tlm_radial/entries.json`：

```json
{
  "pages": [{
    "id": "extra", "title": "扩展", "order": 50,
    "entries": [{
      "id": "extra:wave", "slot": 0, "label": "挥手",
      "icon": "minecraft:bell", "requires_maid": true,
      "command": "say 你好"
    }]
  }]
}
```

- 改完重启生效
- 支持 `max_distance`
- 单机客户端/服务端读同一份

### Java API

```java
@EventBusSubscriber(modid = "mymod")
public final class MyAddon {
    @SubscribeEvent
    public static void register(RegisterRadialEntriesEvent e) {
        e.register(RadialEntry.builder("mymod:wave")
                .page("interact").slot(7)
                .label("挥手").icon("minecraft:bell")
                .requiresMaid(true)
                .command("function mymod:maid/wave")
                .build());
    }
}
```

API 版本：`GltRadial.API_VERSION = 1`

## 构建

不依赖 Gradle / 网络，直接使用实例里的 jar：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File build.ps1
```

产物在 `mod/gltradial/build/tlmradial-<时间戳>.jar`；发布时改名为 `tlmradial-0.2.0.jar`。

## 已知限制

- JSON/Java 条目没有服务端→客户端同步，建议单机；联机时以服务端为准但客户端可能看不到
- 条目文字硬编码中文
- `icon` 字段暂未渲染
- 拍照功能暂未实现

## 许可与致谢

- 本模组代码：MIT（见 `LICENSE`）
- 不包含车万女仆、动作拓展、爱恋、promaid 的任何代码或素材
- 车万女仆：TartaricAcid 等；动作拓展：Mero；爱恋：作者；promaid：Khragg
- 非官方附属，免费、非商业
